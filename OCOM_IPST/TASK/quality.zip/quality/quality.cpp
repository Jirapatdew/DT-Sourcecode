#include "quality.h"

int rectangle(int R, int C, int H, int W, int Q[3001][3001]) {
	return R*C/2;
}
