void init(int* nn, int* xx0, int* yy0);
bool examine(int x, int y);
void solution(int xxc, int yyc);
