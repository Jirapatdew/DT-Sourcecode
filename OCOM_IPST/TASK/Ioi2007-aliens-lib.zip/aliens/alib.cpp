#include <cstdio>
#include <cstdlib>

static int n,m;
static int x0,y0;
static int xc,yc;
static int counter;

static void read_input()
{
  scanf("%d %d",&n,&m);
  scanf("%d %d",&x0,&y0);
  scanf("%d %d",&xc,&yc);
}

void init(int* nn, int* xx0, int* yy0)
{
  read_input();
  counter = 0;
  *nn = n;
  *xx0 = x0;
  *yy0 = y0;
}

bool examine(int x, int y)
{
  counter++;
  int size = 2*m + (m/2);
  printf("%d: examine %d %d - ",counter,x,y);
  if((x < 1) || (x > n) || (y < 1) || (y > n)) {
    printf("out of bound.\n");
    exit(0);
  }
  bool res;
  if((x < xc-size) || (x > xc+size) || 
     (y < yc-size) || (y > yc+size))
    res = false;
  else {
    int dx = (x - (xc - size))/m;
    int dy = (y - (yc - size))/m;
    res = (dx + dy)%2==0;
  }
  if(res)
    printf("true\n");
  else
    printf("false\n");
  return res;
}

void solution(int xxc, int yyc)
{
  printf("solution %d %d\n",xxc,yyc);
  if((xxc==xc) && (yyc==yc))
    printf("Correct.\n");
  else
    printf("Incorrect.\n");
  exit(0);
}
