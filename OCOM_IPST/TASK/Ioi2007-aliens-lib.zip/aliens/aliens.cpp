#include "alib.h"

int n,x0,y0;

main()
{
  init(&n,&x0,&y0);

  int x = x0;
  int y = y0;
  while(examine(x,y))
    x++;
  solution(x,y);
}
